// Select the navbar element
let navbar = document.querySelector('.header .navbar');

// Add 'active' class to navbar when menu button is clicked
document.querySelector('#menu-btn').onclick = () => {
    navbar.classList.add('active');
}

// Remove 'active' class from navbar when close button is clicked
document.querySelector('#nav-close').onclick = () => {
    navbar.classList.remove('active');
}

// Select the search form element
let searchForm = document.querySelector('.search-form');

// Add 'active' class to search form when search button is clicked
document.querySelector('#search-btn').onclick = () => {
    searchForm.classList.add('active');
}

// Remove 'active' class from search form when close button is clicked
document.querySelector('#close-search').onclick = () => {
    searchForm.classList.remove('active');
}

// Handle window scroll event
window.onscroll = () => {
    // Remove 'active' class from navbar when scrolling
    navbar.classList.remove('active');
    
    // Add 'active' class to header when window is scrolled down
    if (window.scrollY > 0) {
        document.querySelector('.header').classList.add('active');
    } else {
        document.querySelector('.header').classList.remove('active');
    }
};

// Handle window load event
window.onload = () => {
    // Add 'active' class to header if window is scrolled down on load
    if (window.scrollY > 0) {
        document.querySelector('.header').classList.add('active');
    } else {
        document.querySelector('.header').classList.remove('active');
    }
};
