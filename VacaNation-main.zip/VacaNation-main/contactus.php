<?php
    // Database connection details
    $db_hostname = "127.0.0.1";
    $db_username = "root";
    $db_password = "";
    $db_name = "tour";

    // Establishing the connection to the database
    $conn = mysqli_connect($db_hostname, $db_username, $db_password, $db_name);

    // Check if the connection was successful
    if (!$conn) {
        echo "Connection Failed: " . mysqli_connect_error();
        exit;
    }

    // Retrieving form data
    $name = $_POST['name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $subject = $_POST['subject'];
    $message = $_POST['message'];

    // Inserting data into the database
    $sql = "INSERT INTO contact (Name, Email, Phone, Subject, Message) VALUES ('$name', '$email', '$phone', '$subject', '$message')";
    $result = mysqli_query($conn, $sql);

    // Checking if the query was successful
    if (!$result) {
        echo "Error: " . mysqli_error($conn);
        exit;
    }

    // Confirmation message
    echo "We will contact you soon";

    // Closing the database connection
    mysqli_close($conn);
?>
